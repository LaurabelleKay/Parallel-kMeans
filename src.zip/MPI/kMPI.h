#include "../kMeans.h"

void reduceCentroids(void *in, void *out, int *len, MPI_Datatype *typeptr);
